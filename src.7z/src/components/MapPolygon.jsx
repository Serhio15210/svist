import React, {useEffect} from 'react';
import hexToRgba from 'hex-to-rgba';
import {Polygon} from "react-native-maps";

const MapPolygon = ({item}) => {
    const hexToRgbA = (hex) => {
        let c;
        if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
            c = hex.substring(1).split('');
            if (c.length === 3) {
                c = [c[0], c[0], c[1], c[1], c[2], c[2]];
            }
            c = '0x' + c.join('');
            return 'rgba(' + [(c >> 16) & 255, (c >> 8) & 255, c & 255].join(',') + ',0.24)';
        }
        throw new Error('Bad Hex');
    }

    return (
        <Polygon key={item?.id} coordinates={item?.polygon}
                 fillColor={hexToRgba(item?.color,0.24)}
                 strokeColor={item?.color}
                 strokeWidth={2}/>
    );
};

export default React.memo(MapPolygon);