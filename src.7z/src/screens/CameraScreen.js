import React from 'react';


import {Image, StyleSheet, Text, TouchableOpacity, View} from "react-native";
const CameraScreen = () => {

    return (
      <View></View>
    );
};
const styles = StyleSheet.create({
    body: {
        flex: 1,
    },
    preview: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-end',
    }
});
export default CameraScreen;
