export const BASE_URL='https://scooter3.tcl.quazom.com'
export const ACCESS_TOKEN='99fa1ca9c617543f04b8c349d25cec52'
