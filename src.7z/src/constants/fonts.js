
export const GT = 'GT'
export const GT_BOLD = 'GTB'
